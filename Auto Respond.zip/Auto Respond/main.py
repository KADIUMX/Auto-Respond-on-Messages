import requests

trigger_msg = "WHEN_THE_TOKEN_SEES_THIS_MESSAGE_IT_RESPONDS"
message = "INPUT_THE_MESSAGE_THE_TOKEN_SHOULD_RESPOND_ON"
CHANNEL_ID = "CHANNEL_ID"
TOKEN = "DISCORD_ACCOUNT_TOKEN"
MESSAGES_URL = "https://discordapp.com/api/v8/channels/{channel_id}/messages" ; SEND_MESSAGE_URL = "https://discordapp.com/api/v8/channels/{channel_id}/messages"

HEADERS = {
    "Authorization": f"{TOKEN}",
    "User-Agent": "MyBot/1.0"
}

while True:
    # Get the latest messages in the channel
    response = requests.get(MESSAGES_URL.format(channel_id=CHANNEL_ID), headers=HEADERS)
    import json
    data = json.loads(response.text)

    if data[0]["content"] == f"{trigger_msg}":
        # Send a message "Worked" in the same channel
        requests.post(SEND_MESSAGE_URL.format(channel_id=CHANNEL_ID), headers=HEADERS, json={
            "content": f"{message}"
        })

    import time
    time.sleep(0.1)